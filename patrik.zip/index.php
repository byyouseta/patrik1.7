<?php

header('Location: public/');