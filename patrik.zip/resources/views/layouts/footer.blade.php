<footer class="main-footer">
  <!-- To the right -->
  <div class="pull-right hidden-xs">
    PATRIK v 1.7
  </div>
  <!-- Default to the left -->
  <strong>Copyright &copy; 2021 IT <a href="https://rsupsurakarta.co.id" target="_blank">RSUP Surakarta</a>.</strong> All rights reserved.
</footer>