<!DOCTYPE html>
<html lang="en">

<head>
    <title>Undangan Rapat <?php echo e($agenda->nama_agenda); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
    <style>
        header {
            position: fixed;
            top: -40px;
            left: 0px;
            right: 0px;
            height: 0px;

            /** Extra personal styles **/
            /* background-color: #03a9f4; */
            color: black;
            text-align: right;
            line-height: 12px;
        }

        footer {
            position: fixed;
            bottom: -60px;
            left: 20px;
            right: 20px;
            height: 120px;

            /** Extra personal styles **/
            /* background-color: #03a9f4; */
            color: black;
            text-align: right;
            font-size: 11px;
            line-height: 12px;
        }
    </style>
</head>
<header>
    <table class="table table-borderless" style="margin-bottom : 0px;padding-bottom:0px;">
        <thead>
            <tr>
                
                <th class="align-middle pl-0">
                    <center><img src=<?php echo e(public_path('adminlte/dist/img/KopSurat2.jpg')); ?> alt="Kop Surat"
                            width="650px" /></center>
                </th>
            </tr>
        </thead>
    </table>
</header>

<body>
    <main>

        <?php
        $arrhari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        $hari = new DateTime($agenda->tanggal);
        //$hari = $arrhari[$tanggal->format('N')];
        $tanggal = new DateTime($agenda->tanggal);
        ?>
        <style type="text/css">
            table tr td,
            table tr th {
                font-size: 10pt;

            }

            hr.new4 {
                border: 2px solid black;
                margin-left: auto;
                margin-right: auto;
                margin-top: 0em;
                margin-bottom: 0em;
            }

            p.ex1 {
                margin-left: auto;
                margin-right: auto;
                margin-top: auto;
                margin-bottom: auto;
            }
        </style>

        
        <?php
            $jmlundangan = $peserta->count();
            $urutan2 = ceil($jmlundangan / 2);
            // $index = 1;

            foreach ($peserta as $index => $user) {
                # code...
                $undangan[$index] = $user->name;
            }

            $kanan = $urutan2;
            $nokiri = 1;
            $nokanan = $urutan2 + 1;

        ?>


        <table class="table table-borderless table-sm"
            style="margin-top:110px; padding-top:0px; margin-bottom:0px; padding-bottom:0px">
            <tbody>
                <tr>
                    <th colspan='4' class="text-center" style="padding-top: 0px;">
                        <h4 style="padding-bottom:1px; margin-bottom:1px;">Undangan</h4>
                        <p style="padding-top: 1px; padding-bottom:1px; margin-top:1px; margin-bottom:1px;">
                            <?php echo e($agenda->no_undangan); ?>

                        </p>
                    </th>
                </tr>
                <tr>
                    <td colspan='4' style="padding-left: 40px">Yth. Bapak Ibu </td>
                </tr>

            </tbody>
        </table>
        <table class="table table-borderless table-sm" style="margin-top:0%; padding-top:0%; margin-bottom:0%">
            <?php for($i = 0; $i < $urutan2; $i++): ?>
                <tr>
                    <td class="ml-5" style="padding-top:1px;padding-bottom:1px; padding-left:45px;">
                        <?php echo e($nokiri . '. ' . $undangan[$i]); ?>

                    </td>
                    <?php
                        $kanan = $urutan2 + $i;
                        $nokiri++;
                    ?>
                    <?php if(!empty($undangan[$kanan])): ?>
                        <td style="padding-top:1px;padding-bottom:1px; padding-right:40px">
                            <?php echo e($nokanan . '. ' . $undangan[$kanan]); ?></td>
                    <?php endif; ?>
                    <?php
                        $nokanan++;
                    ?>
                </tr>
            <?php endfor; ?>
        </table>
        <?php
            $keterangan = explode(PHP_EOL, $agenda->keterangan);
        ?>
        <table class="table table-borderless table-sm" style="margin-top:1px;">
            <tbody>
                <tr>
                    <td colspan='3' style="padding-top: 1px; padding-bottom:1px; padding-left:40px;">Di RSUP
                        Surakarta</td>
                </tr>
                <tr>
                    <td colspan='3' style="padding-top: 1px; padding-bottom:1px; padding-left:40px;">Mengharap
                        kehadiran
                        Bapak/Ibu/Saudara/i pada :</td>
                </tr>
                <tr>
                    <th class="text-left ml-5"
                        style="width: 25%; padding-top: 1px; padding-bottom:1px; padding-left:40px;">Hari,Tanggal
                    </th>
                    <th class="text-right" style="width: 5%; padding-top: 1px; padding-bottom:1px;">:</th>
                    <th style="width: 70%; padding-top: 1px; padding-bottom:1px;"><?php echo e($arrhari[$tanggal->format('N')]); ?>,
                        <?php echo e($tanggal->format('d-m-Y')); ?></th>
                </tr>
                <tr>
                    <th class="text-left ml-5"
                        style="width: 25%; padding-top: 1px; padding-bottom:1px; padding-left:40px;">Waktu</th>
                    <th class="text-right" style="width: 5%; padding-top: 1px; padding-bottom:1px;">:</th>
                    <th style="width: 70%; padding-top: 1px; padding-bottom:1px;"><?php echo e($agenda->waktu_mulai); ?> -
                        <?php echo e($agenda->waktu_selesai); ?></th>
                </tr>
                <tr>
                    <th class="text-left ml-5"
                        style="width: 25%; padding-top: 1px; padding-bottom:1px; padding-left:40px;">Tempat</th>
                    <th class="text-right" style="width: 5%; padding-top: 1px; padding-bottom:1px;">:</th>
                    <th style="width: 70%; padding-top: 1px; padding-bottom:1px;"><?php echo e($agenda->ruangan->nama); ?></th>
                </tr>
                <tr>
                    <th class="text-left ml-5"
                        style="width: 25%; padding-top: 1px; padding-bottom:1px; padding-left:40px;">Acara</th>
                    <th class="text-right" style="width: 5%; padding-top: 1px; padding-bottom:1px;">:</th>
                    <th style="width: 70%; padding-top: 1px; padding-bottom:1px;">
                        <?php echo e($agenda->nama_agenda); ?>

                    </th>
                </tr>

                <tr>
                    <th class="text-left ml-5"
                        style="width: 25%; padding-top: 1px; padding-bottom:1px; padding-left:40px;">Keterangan</th>
                    <th class="text-right" style="width: 5%; padding-top: 1px; padding-bottom:1px;">:</th>
                    <th style="width: 70%; padding-top: 1px; padding-bottom:1px;">
                        <?php $__currentLoopData = $keterangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keterangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p style="padding-top: 1px; padding-bottom:1px; margin-top:1px; margin-bottom:1px;">
                                <?php echo e($keterangan); ?> </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </th>
                </tr>
                <tr>
                    <td colspan='3' style="padding-top: 1px; padding-bottom:1px; padding-left:40px;">Atas
                        kehadirannya diucapkan terima
                        kasih.</td>
                </tr>

            </tbody>
        </table>
        <table class="table table-borderless">
            <tbody>
                <tr>
                    <td style="width: 50%"></td>
                    <td class="text-center" style="width: 50%; padding-right:40px"><?php echo e($agenda->jab_pengundang); ?></td>
                </tr>
                <tr>
                    <td style="width: 80%"></td>
                    <td></td>
                </tr>
                <tr>
                    <td style="width: 80%"></td>
                    <td></td>
                </tr>
                <tr>
                    <td style="width: 50%"></td>
                    <th class="text-center" style="width: 50%; padding-right:40px"><?php echo e($agenda->pengundang); ?></th>
                </tr>
            </tbody>

        </table>
    </main>
    <footer>
        
        <table class="table table-sm table-borderless" style="margin-bottom:100px;">
            <tr>
                
                <td
                    style="color: black; padding-top:0px; padding-bottom:0px; font-size:11px; text-align:center; border:1px solid black">
                    
                    Kementerian Kesehatan tidak menerima suap dan/ atau gratifikasi dalam bentuk apapun. Jika terdapat
                    potensi suap atau gratifikasi silahkan laporkan melalui HALO KEMENKES 1500567 dan
                    <a href='https://wbs.kemkes.go.id'>https://wbs.kemkes.go.id</a>. Untuk verifikasi keaslian
                    tandatangan elektronik, silahkan unggah dokumen
                    pada laman <a href='https://tte.kominfo.go.id/verifyPDF'>https://tte.kominfo.go.id/verifyPDF</a>
                </td>
                <td class="text-right" style='width:20%'>
                    <img src="adminlte/dist/img/kars_paripurna.png" alt="Logo KARS" width="50" height="50">
                    <img src="adminlte/dist/img/LogoBLUSpeed.png" alt="Logo Blu Speed" width="50" height="50">
                </td>
            </tr>
            <tr>
                <td style="color: grey; padding-top:20px; padding-bottom:0px; font-size:11px; text-align:right;"
                    colspan='2'>
                    Dicetak dari PATRIK (Rapat Elektronik) pada <?php echo e(\Carbon\Carbon::now()->format('d/m/Y h:i:s')); ?>

                </td>
            </tr>
        </table>
        
    </footer>

</body>

</html>
