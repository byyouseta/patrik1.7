<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Daftar Ruangan'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<div class="row">
    <!-- left column -->
    <div class="col-md-8">
        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title">Tambah Ruangan</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form role="form" action="/ruangan/tambahruangan" method="post">
                <?php echo e(csrf_field()); ?>

                <!-- text input -->
                    <div class="form-group">
                        <label>Nama Ruangan</label>
                        <input type="text" class="form-control" placeholder="Masukkan Nama Ruangan" name="nama" value="<?php echo e(old('nama')); ?>">
                        <?php if($errors->has('nama')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('nama')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Lokasi</label>
                        <input type="text" class="form-control" placeholder="Masukkan Lokasi Ruangan" name="lokasi" value="<?php echo e(old('lokasi')); ?>">
                        <?php if($errors->has('lokasi')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('lokasi')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Keterangan</label>
                        <textarea class="form-control" rows="3" placeholder="Masukkan Keterangan" name="keterangan"><?php echo e(old('keterangan')); ?></textarea>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a href="/ruangan" class="btn btn-warning">Kembali</a>
                    </div>
                </form>
            </div>
    <!-- /.box-body -->
        </div>
        <?php if(!empty($pesan)): ?>
        <div class="alert alert-success alert-block">
		        <button type="button" class="close" data-dismiss="alert">×</button>	
                <strong><?php echo e($pesan); ?></strong>
	    </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>