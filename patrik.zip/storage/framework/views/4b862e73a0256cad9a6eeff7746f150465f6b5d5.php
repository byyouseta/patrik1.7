<!-- Menghubungkan dengan view template master -->

<?php $__env->startSection('head'); ?>
    <!-- DataTables -->
    <link rel="stylesheet"
        href="<?php echo e(asset('adminlte/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Daftar Agenda'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">

                <!-- /.box-header -->
                <div class="box-body">
                    <table class="table table-hover" id="example2">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Agenda</th>
                                <th>Tanggal</th>
                                <th>Waktu Mulai</th>
                                <th>Waktu Selesai</th>
                                <th>Tempat</th>
                                <th>Status Presensi</th>
                                <th>Waktu Presensi</th>

                                <th>Pengundang</th>

                                <th> Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (isset($cari)) {
                                $halaman = $agenda->currentPage();
                                $per_page = $agenda->perPage();
                                $no = ($halaman - 1) * $per_page + 1;
                            } else {
                                $no = 1;
                            }
                            $now = new DateTime();
                            $now = $now->format('Y-m-d');
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($a->nama_agenda); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($a->tanggal)->format('d M Y')); ?></td>
                                    <td><?php echo e($a->waktu_mulai); ?></td>
                                    <td><?php echo e($a->waktu_selesai); ?></td>
                                    <td><?php echo e($a->nama_ruangan); ?></td>
                                    <td>
                                        <?php if($a->presensi == 'sudah'): ?>
                                            <span class="label label-success">
                                            <?php else: ?>
                                                <span class="label label-danger">
                                        <?php endif; ?>
                                        <?php echo e($a->presensi); ?></span>
                                    </td>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($a->waktu_presensi)->format('d M Y H:i:s')); ?>

                                    </td>
                                    <td>
                                        <?php echo e($a->pengundang); ?>

                                    </td>

                                    <td>

                                        <div class="btn-group">
                                            
                                            <a href="/presensi/<?php echo e(Crypt::encrypt($a->id)); ?>/<?php echo e(Crypt::encrypt(Auth::user()->id)); ?>"
                                                class="btn btn-success btn-sm <?php if($a->presensi == 'sudah' or $now != $a->tanggal): ?> disabled <?php endif; ?>" data-toggle="tooltip"
                                                data-placement="bottom" title="Presensi">
                                                <i class="fa fa-sign-in"></i> Klik Presensi
                                            </a>
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10" class="text-center">Belum ada data agenda yang dibuat</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>

                    </table>
                    <!-- /.box-body -->
                </div>

                

            </div>
            <!-- /.box -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(function() {
            $('#example1').DataTable()
            $('#example2').DataTable({
                'paging': true,
                'lengthChange': true,
                'searching': true,
                'ordering': true,
                'info': true,
                "scrollY": false,
                "scrollX": true,
                "autoWidth": false,
                "fixedHeader": {
                    "header": false,
                    "footer": false
                },
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>