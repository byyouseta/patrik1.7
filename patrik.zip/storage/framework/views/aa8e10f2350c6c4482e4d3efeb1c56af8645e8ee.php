<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Manual Sistem'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<div class="box">
    <?php if(Auth::user()->level=='admin'): ?>
      <div class="box-header">
          <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-default">
              <i class="fa fa-plus-circle"></i> Tambah File</button> </a>
      </div>
    <?php endif; ?>
    <?php if(count($errors) > 0): ?>
      <div class="alert alert-danger">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($error); ?> <br/>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endif; ?>
    <?php
      $no=1;   
    ?>
    <div class="box-body">
      <table class="table table-striped">
          <tr>
            <th style="width: 10px">No</th>
            <th>Nama File</th>
            <th>Keterangan</th>
            <th style="width: 40px">Action</th>
          </tr>
        </tr>
          <?php $__empty_1 = true; $__currentLoopData = $manual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <th style="width: 5%"><?php echo e($no++); ?></th>
            <th><?php echo e($item->nama); ?></th>
            <th><?php echo e($item->keterangan); ?></th>
            <th style="width: 10%">
              <div class="btn-group">
                <a href="/about/view/<?php echo e(Crypt::encrypt($item->namafile)); ?> " target="_blank" class="btn btn-primary btn-sm">
                <i class="fa fa-eye"></i></a>
                <?php if(Auth::user()->level=='admin'): ?>
                  
                  <a href="/about/delete/<?php echo e(Crypt::encrypt($item->id)); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="Hapus">
                    <i class="fa fa-trash-o"></i></a>
                <?php endif; ?>
              </div>
            </th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <th colspan="4" class="text-center">Data Kosong</th>
          <?php endif; ?>
        
        </tr>        
      </table>
    </div>
    <!-- /.box-body -->
</div>

<!--modal -->
<div class="modal fade" id="modal-default">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tambah File</h4>
        </div>
        <div class="modal-body">
        <form method="post" action="/about/upload" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label>Nama File</label>
                    <input type='text' class="form-control" name='namafile' />
                </div>
                <div class="form-group">
                    <label>Keterangan</label>
                    <textarea class="form-control" rows="3" placeholder="Keterangan" name="keterangan"></textarea>
                  </div>
                <div class="form-group">
                    <label for="filepdf">File input</label>
                    <input type="file" id="filepdf" name="fileupload">
  
                    <p class="help-block">Maksimal file 2Mb</p>
                  </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Kembali</button>
            <button type="submit" class="btn btn-primary">Upload</button>
        </div>
        </form>
    </div>
    <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>