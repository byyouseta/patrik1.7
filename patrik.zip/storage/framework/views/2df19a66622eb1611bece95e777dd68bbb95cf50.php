<?php $__env->startSection('judul_halaman'); ?>
    Profil <?php echo e(Auth::user()->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Update Profile</h3>
                </div>
                
                <!-- /.box-header -->
                <form role="form" action="/profil/update/<?php echo e(Auth::user()->id); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">
                        <div class="col-md-12">
                            <div class="col-md-1">
                                <?php if(isset($user->foto)): ?>
                                    <img src="<?php echo e(asset('foto_profil/' . $user->foto)); ?>" class="img-circle"
                                        alt="User Image" style="height: 80px">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('adminlte/dist/img/avatar-default.png')); ?>" class="img-circle"
                                        alt="User Image" style="height: 80px">
                                <?php endif; ?>
                            </div>
                            <div class="col-md-11">
                                <div class="form-group">
                                    <label for="exampleInputFile">Ubah Profile</label>
                                    <input type="file" id="exampleInputFile" name="foto">

                                    <p class="help-block">File berbentuk jpeg/jpg/png dengan maksimal ukuran 200KB</p>
                                    <?php if($errors->has('foto')): ?>
                                        <div class="text-danger">
                                            <?php echo e($errors->first('foto')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">

                            <!-- text input -->
                            <div class="form-group">
                                <label>NIP/ NO PIN Simadam</label>
                                <input type="text" class="form-control" value="<?php echo e(Auth::user()->username); ?>"
                                    name="username">
                                <?php if($errors->has('username')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('username')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Nama Pengguna</label>
                                <input type="text" class="form-control" value="<?php echo e(Auth::user()->name); ?>" name="name">
                                <?php if($errors->has('name')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('name')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Kontak</label>
                                <input type="text" class="form-control" value="<?php echo e($user->pegawai->no_hp); ?>" name="nohp">
                                <?php if($errors->has('nohp')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('nohp')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Alamat</label>
                                <textarea class="form-control" name="alamat"><?php echo e($user->pegawai->alamat); ?></textarea>
                                <?php if($errors->has('alamat')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('alamat')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <!-- text input -->
                            <div class="form-group">
                                <label>Email Pengguna</label>
                                <input type="text" class="form-control" value="<?php echo e(Auth::user()->email); ?>" name="email">
                                <?php if($errors->has('email')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('email')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Jabatan</label>
                                <input type="text" class="form-control" placeholder="Masukkan Jabatan" name="jabatan"
                                    value="<?php echo e($user->pegawai->jabatan); ?>">
                                <?php if($errors->has('jabatan')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('jabatan')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Unit</label>
                                <select class="form-control select2" name="unit">
                                    <option value="">Pilih</option>
                                    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($u->id); ?>" <?php if($u->id == $user->unit_id): ?> selected <?php endif; ?>>
                                            <?php echo e($u->nama_unit); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('unit')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('unit')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Update Terakhir</label>
                                <input type="text" class="form-control"
                                    value="<?php echo e(\Carbon\Carbon::parse(Auth::user()->updated_at)->format('d M Y H:i:s')); ?>"
                                    disabled>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>