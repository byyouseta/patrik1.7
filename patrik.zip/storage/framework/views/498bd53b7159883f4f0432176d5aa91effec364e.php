<?php $__env->startSection('judul_halaman', 'Change Password'); ?>
<?php $__env->startSection('konten'); ?>
<div class="row">
    <!-- left column -->
    <div class="col-md-6">
        <!-- general form elements -->
        <div class="box box-primary">
        
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" action="/password/ganti" method="post">
            <?php echo csrf_field(); ?>
            <div class="box-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Password lama</label>
                    <input type="password" class="form-control" name="password" placeholder="Password Lama">
                </div>

                <?php if($errors->has('password')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('password')); ?>

                    </div>
                <?php endif; ?>

                <div class="form-group">
                    <label for="exampleInputPassword1">Password Baru</label>
                    <input type="password" class="form-control" name="password_new" placeholder="Password Baru">
                </div>

                <?php if($errors->has('password_new')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('password_new')); ?>

                    </div>
                <?php endif; ?>

                <div class="form-group">
                    <label for="exampleInputPassword1">Ulangi Password Baru</label>
                    <input type="password" class="form-control" name="password_confirmation" placeholder="Ulangi Password Baru">
                </div>

                <?php if($errors->has('password_confirmation')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('password_confirmation')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
        </div>
        <!-- /.box -->
        <?php if(!empty($pesan)): ?>
        <div class="alert alert-success alert-block">
		        <button type="button" class="close" data-dismiss="alert">×</button>	
                <strong><?php echo e($pesan); ?></strong>
	    </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>