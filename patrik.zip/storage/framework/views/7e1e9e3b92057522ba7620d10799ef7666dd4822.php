<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Daftar Agenda'); ?>
<?php $__env->startSection('head'); ?>
    <!-- daterange picker -->
    <link rel="stylesheet" href="<?php echo e(asset('adminlte/bower_components/bootstrap-daterangepicker/daterangepicker.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet"
        href="<?php echo e(asset('adminlte/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">

                    <div class="btn-group">

                        <a href="/agenda/tambah" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="right"
                            title="Tambah Agenda">
                            <i class="fa fa-plus-circle"></i> Tambah</a>


                    </div>

                    <div class="box-tools">
                        
                        <form action="/agenda/cari" method="get">
                            
                            <div class="input-group input-group-sm" style="width: 220px;">
                                <input type="text" class="form-control" id="reservation" name="cari" <?php if(Request::get('cari')): ?>
                                value="<?php echo e(Request::get('cari')); ?>"
                            <?php else: ?>
                                value="<?php echo e(\Carbon\Carbon::now()->startOfMonth()->format('d/m/Y')); ?>-<?php echo e(\Carbon\Carbon::now()->endOfMonth()->format('d/m/Y')); ?>"
                                <?php endif; ?> autocomplete="off">
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-info btn-flat">Tampilkan</button>
                                </span>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive">
                    <table class="table table-hover" id="example1">
                        <thead class="text-middle">
                            <tr>
                                <th>No</th>
                                <th>Nama Agenda</th>
                                <th>Tanggal</th>
                                <th>Waktu Mulai</th>
                                <th>Waktu Selesai</th>
                                <th>Tempat</th>
                                <th>Status</th>
                                <!--<th>Jumlah Peserta</th>-->
                                <th>PIC</th>
                                <th>Diajukan</th>
                                <th style="width: 150px;"> Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (isset($cari)) {
                                $halaman = $agenda->currentPage();
                                $per_page = $agenda->perPage();
                                $no = ($halaman - 1) * $per_page + 1;
                            } else {
                                $no = 1;
                            }
                            $now = new DateTime();
                            $now = $now->format('Y-m-d');
                            ?>
                            <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($a->nama_agenda); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($a->tanggal)->format('d M Y')); ?></td>
                                    <td><?php echo e($a->waktu_mulai); ?></td>
                                    <td><?php echo e($a->waktu_selesai); ?></td>
                                    <td><?php echo e($a->nama_ruangan); ?></td>
                                    <td>
                                        <?php if($a->tanggal < $now and $a->status != 'Selesai'): ?>
                                            <span class="label label-danger"><?php echo e($a->status); ?></span>
                                        <?php elseif($a->status=="Dijadwalkan"): ?>
                                            <span class="label label-success"><?php echo e($a->status); ?></span>

                                        <?php elseif($a->status=="Pengajuan"): ?>
                                            <span class="label label-warning"><?php echo e($a->status); ?></span>
                                        <?php elseif($a->status=="Ditolak"): ?>
                                            <span class="label label-default"><?php echo e($a->status); ?></span>
                                        <?php else: ?>
                                            <span class="label label-primary"><?php echo e($a->status); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($a->pic_name); ?>

                                    </td>
                                    <td><?php echo e(\Carbon\Carbon::parse($a->created_at)->format('d M Y H:i:s')); ?></td>
                                    <td class="text-center">
                                        <div class="btn-group">
                                            <a href="/agenda/undangan/<?php echo e(Crypt::encrypt($a->id)); ?>"
                                                class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="bottom"
                                                title="Detail">
                                                <i class="fa fa-info-circle"></i></a>
                                            
                                            <?php if(Auth::user()->id == $a->pic or Auth::user()->level == 'admin'): ?>

                                                <a href="/agenda/edit/<?php echo e(Crypt::encrypt($a->id)); ?>"
                                                    class="btn btn-warning btn-sm" data-toggle="tooltip"
                                                    data-placement="bottom" title="Ubah">
                                                    <i class="fa fa-edit"></i></a>
                                                <a href="/agenda/hapus/<?php echo e(Crypt::encrypt($a->id)); ?>"
                                                    class="btn btn-danger btn-sm delete-confirm" data-toggle="tooltip"
                                                    data-placement="bottom" title="Hapus">
                                                    <i class="fa fa-trash-o"></i></a>

                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                    <!-- /.box-body -->
                </div>

                

            </div>
            <!-- /.box -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugin'); ?>
    <!-- date-range-picker -->
    <script src="<?php echo e(asset('adminlte/bower_components/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <!-- DataTables -->
    <script src="<?php echo e(asset('adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

    <script>
        $(function() {
            $('#example1').DataTable()
            $('#example2').DataTable({
                'paging': true,
                'lengthChange': true,
                'searching': true,
                'ordering': true,
                'info': true,
                'autoWidth': false
            })
            //Date range picker
            // $('#reservation').daterangepicker({
            //     locale: {
            //         format: 'DD/MM/YYYY'
            //     }
            // })
            $('#reservation').daterangepicker({
                autoUpdateInput: false,
                locale: {
                    cancelLabel: 'Clear'
                }
            })
            $('#reservation').on('apply.daterangepicker', function(ev, picker) {
                $(this).val(picker.startDate.format('DD/MM/YYYY') + '-' + picker.endDate.format(
                    'DD/MM/YYYY'));
            })

            $('#reservation').on('cancel.daterangepicker', function(ev, picker) {
                $(this).val('');
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>