<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Daftar Agenda'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="row">
	<div class="col-xs-12">
		<div class="box">
			<div class="box-header">
				
				<div class="btn-group">
					
					<a href="/agenda/tambah" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="right" title="Tambah Agenda">
					<i class="fa fa-plus-circle"></i> Tambah</a>
					
					
				</div>
				
				<div class="box-tools">
					<form action="/agenda/cari" method="get">
						
						<div class="input-group input-group-sm" style="width: 150px;">
							<input type="text" name="cari" class="form-control pull-right" placeholder="Search">

							<div class="input-group-btn">
								<button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<!-- /.box-header -->
			<div class="box-body table-responsive no-padding">
				<table class="table table-hover">
				<thead><tr>
					<th>No</th>
					<th>Nama Agenda</th>
					<th>Tanggal</th>
					<th>Waktu Mulai</th>
					<th>Waktu Selesai</th>
					<th>Tempat</th>
					<th>Status</th>
					<!--<th>Jumlah Peserta</th>-->
					<th>PIC</th>
					<th>Diajukan</th>
					<th style="width: 150px;"> Action</th>
				</tr></thead>
				<tbody>
					<?php 
						if(isset($cari)){
							$halaman = $agenda->currentPage();
							$per_page = $agenda->perPage();
							$no= (($halaman-1)*$per_page) + 1;
						}
						else{
							$no = 1;
						} 
						$now = new DateTime();
						$now = $now->format('Y-m-d'); 
					?>
					<?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($no++); ?></td>
						<td><?php echo e($a->nama_agenda); ?></td>
						<td><?php echo e($a->tanggal); ?></td>
						<td><?php echo e($a->waktu_mulai); ?></td>
						<td><?php echo e($a->waktu_selesai); ?></td>
						<td><?php echo e($a->nama_ruangan); ?></td>
						<td>
							<?php if(($a->tanggal<$now) AND ($a->status<>"Selesai")): ?>
								<span class="label label-danger"><?php echo e($a->status); ?></span>
							<?php elseif($a->status=="Dijadwalkan"): ?>
								<span class="label label-success"><?php echo e($a->status); ?></span>
							
							<?php elseif($a->status=="Pengajuan"): ?>
								<span class="label label-warning"><?php echo e($a->status); ?></span>
							<?php else: ?>
								<span class="label label-primary"><?php echo e($a->status); ?></span>
							<?php endif; ?>
						</td>
						<!--<td></td>-->
						<td><?php echo e($a->pic); ?></td>
						<td><?php echo e($a->created_at); ?></td>
						<td>
						<div class="btn-group">
							<a href="/agenda/undangan/<?php echo e(Crypt::encrypt($a->id)); ?>" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="bottom" title="Detail">
								<i class="fa fa-info-circle"></i></a>
							<a href="/presensi/undangan/<?php echo e(Crypt::encrypt($a->id)); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="bottom" title="Presensi">
								<i class="fa fa-sign-in"></i></a>
							<?php if((Auth::user()->name==$a->pic) OR (Auth::user()->level=='admin')): ?>
								<?php if($now < $a->tanggal): ?> 
								<a href="/agenda/edit/<?php echo e(Crypt::encrypt($a->id)); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="bottom" title="Ubah">
									<i class="fa fa-edit"></i></a>
								<a href="/agenda/hapus/<?php echo e(Crypt::encrypt($a->id)); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="Hapus">
									<i class="fa fa-trash-o"></i></a>
								<?php else: ?>
								<a href="/agenda/edit/<?php echo e(Crypt::encrypt($a->id)); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="bottom" title="Ubah" disabled>
									<i class="fa fa-edit"></i></a>
								<a href="/agenda/hapus/<?php echo e(Crypt::encrypt($a->id)); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="Hapus" disabled>
									<i class="fa fa-trash-o"></i></a>
								<?php endif; ?>
							<?php endif; ?>
						</div>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				
				</table>
				<!-- /.box-body -->
			</div>
			
			<div class="box-footer clearfix">
				
              <ul class="pagination pagination-sm no-margin pull-right">
               
                <li>
				
					<?php echo e($agenda->appends(Request::get('page'))->links()); ?> 
				
				</li>
                
              </ul>
            </div>
			
		</div>
		<!-- /.box -->
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>