<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Daftar Pegawai'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <div class="btn-group">
                        <a href="/pegawai/tambah" class="btn btn-primary btn-sm"><i class="fa fa-plus-circle"></i>
                            Tambah</a>

                    </div>
                    
                    <div class="box-tools">
                        <form action="/pegawai/cari" method="get">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="cari" class="form-control pull-right" placeholder="Search"
                                    <?php if(Request::get('cari')): ?> value="<?php echo e(Request::get('cari')); ?>" <?php endif; ?>>
                                <div class="input-group-btn">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php
                    if (isset($cari)) {
                        # code...
                        $no = 1;
                    } else {
                        $halaman = $pegawai->currentPage();
                        $per_page = $pegawai->perPage();
                        $no = ($halaman - 1) * $per_page + 1;
                    }
                ?>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIP</th>
                                <th>Nama Pegawai</th>
                                <th>Alamat</th>
                                <th>Unit</th>
                                <th>No Handphone</th>
                                <th style="width: 100px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php if(!empty($cari)): ?>
                                <?php $__currentLoopData = $cari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($p->username); ?></td>
                                        <td><?php echo e($p->name); ?></td>
                                        <td><?php echo e($p->alamat); ?></td>
                                        <td><?php echo e($p->nama_unit); ?></td>
                                        <td><?php echo e($p->no_hp); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="/pegawai/edit/<?php echo e(Crypt::encrypt($p->id)); ?>"
                                                    class="btn btn-warning btn-sm" data-toggle="tooltip"
                                                    data-placement="bottom" title="Ubah">
                                                    <i class="fa fa-edit"></i></a>
                                                <a href="/pegawai/hapus/<?php echo e(Crypt::encrypt($p->id)); ?>"
                                                    class="btn btn-danger btn-sm delete-confirm" data-toggle="tooltip"
                                                    data-placement="bottom" title="Hapus">
                                                    <i class="fa fa-trash-o"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($p->username); ?></td>
                                        <td><?php echo e($p->name); ?></td>
                                        <td><?php echo e($p->pegawai->alamat); ?></td>
                                        <td><?php echo e($p->unit->nama_unit); ?></td>
                                        <td><?php echo e($p->pegawai->no_hp); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="/pegawai/edit/<?php echo e(Crypt::encrypt($p->id)); ?>"
                                                    class="btn btn-warning btn-sm" data-toggle="tooltip"
                                                    data-placement="bottom" title="Ubah">
                                                    <i class="fa fa-edit"></i></a>
                                                <a href="/pegawai/hapus/<?php echo e(Crypt::encrypt($p->id)); ?>"
                                                    class="btn btn-danger btn-sm delete-confirm" data-toggle="tooltip"
                                                    data-placement="bottom" title="Hapus">
                                                    <i class="fa fa-trash-o"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
                <div class="box-footer clearfix">
                    <ul class="pagination pagination-sm no-margin pull-right">

                        <li>
                            <?php if(!empty($cari)): ?>
                                <?php echo e($cari->appends(Request::get('page'))->links()); ?>

                            <?php else: ?>
                                <?php echo e($pegawai->appends(Request::get('page'))->links()); ?>

                            <?php endif; ?>
                        </li>

                    </ul>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <!-- /.content -->
    <div class="modal fade" id="modal-default">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Import Data Pegawai</h4>
                </div>
                <form method="post" action="/pegawai/import_excel" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <label>Pilih file excel</label>
                        <div class="form-group">
                            <input type="file" name="file" required="required">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Keluar</button>
                        <button type="submit" class="btn btn-primary">Import</button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>