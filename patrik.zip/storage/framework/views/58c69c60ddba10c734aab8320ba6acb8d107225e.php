<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Daftar Unit'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<div class="row">
    <!-- left column -->
    <div class="col-md-8">
        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title">Tambah Unit</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form role="form" action="/unit/tambahunit" method="post">
                <?php echo e(csrf_field()); ?>

                <!-- text input -->
                    <div class="form-group">
                        <label>Nama Unit</label>
                        <input type="text" class="form-control" placeholder="Masukkan Nama Unit" name="nama_unit" value="<?php echo e(old('nama_unit')); ?>">
                        <?php if($errors->has('nama_unit')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('nama_unit')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Keterangan</label>
                        <textarea class="form-control" rows="3" placeholder="Masukkan Keterangan" name="keterangan"><?php echo e(old('keterangan')); ?></textarea>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a href="/unit" class="btn btn-warning">Kembali</a>
                    </div>
                </form>
            </div>
    <!-- /.box-body -->
        </div>
        <?php if(!empty($pesan)): ?>
        <div class="alert alert-success alert-block">
		        <button type="button" class="close" data-dismiss="alert">×</button>	
                <a href="/unit" class="btn btn-warning">Kembali</a>
                <strong><?php echo e($pesan); ?></strong>
	    </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>