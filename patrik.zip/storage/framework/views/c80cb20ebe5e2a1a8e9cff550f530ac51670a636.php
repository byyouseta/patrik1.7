<?php if(empty(Auth::user()->username)): ?>
    <script>
        window.location = "/login";
    </script>
<?php endif; ?>
<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Welcome Home'); ?>
<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="box box-default">
                <div class="box-header with-border">

                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h4><i class="icon fa fa-check"></i> Selamat datang <?php echo e(Auth::user()->level); ?>

                            <?php echo e(Auth::user()->name); ?>!</h4>
                        Saat ini Anda login dengan menggunakan username : <?php echo e(Auth::user()->username); ?> </br>
                        Email Anda : <?php echo e(Auth::user()->email); ?> </br>
                        IP Address Anda : <?php echo e(Request::ip()); ?>

                    </div>
                    <div class="alert alert-info alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h4><i class="icon fa fa-check"></i> Perhatian</h4>
                        Untuk mempermudah presensi di PATRIK, kini link presensi bisa dikirimkan PIC RAPAT ke peserta RAPAT.
                        Pastikan data diri EMAIL Anda dan Peserta Rapat sudah sesuai agar notifikasi link presensi
                        rapat bisa terkirim ke alamat email Anda.
                    </div>
                    <?php if(Hash::check(Auth::user()->username, Auth::user()->password)): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert"
                                aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-check"></i> Perhatian</h4>
                            Saat ini Password Anda sesuai setting default, Silahkan ganti password untuk menjaga privasi
                            Anda
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="fa fa-user-md"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Profile</span>
                    <span class="info-box-number"><?php echo e(Auth::user()->name); ?><br></span>
                    <?php echo e(Auth::user()->username); ?>


                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">

            <div class="info-box">
                <a href="/agenda/cari?cari=dijadwalkan">
                    <span class="info-box-icon bg-green"><i class="fa fa-calendar-check-o"></i></span>
                </a>
                <div class="info-box-content">
                    <span class="info-box-text">Agenda Dijadwalkan</span>
                    <span class="info-box-number"><?php echo e($agenda_terjadwal); ?></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->

        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <a href="/agenda/cari?cari=pengajuan">
                    <span class="info-box-icon bg-yellow"><i class="fa fa-calendar-plus-o"></i></span>
                </a>
                <div class="info-box-content">
                    <span class="info-box-text">Agenda Pengajuan</span>
                    <span class="info-box-number"><?php echo e($agenda_diajukan); ?></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon bg-red"><i class="fa fa-users"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Pegawai</span>
                    <span class="info-box-number"><?php echo e($pegawai); ?></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>