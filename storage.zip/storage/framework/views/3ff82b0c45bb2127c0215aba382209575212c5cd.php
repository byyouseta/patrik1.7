<?php $__env->startSection('head'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('adminlte/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Agenda'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">

                <div class="box-header">
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?> <br />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <?php
                        $now = new DateTime();
                        $now = $now->format('Y-m-d');
                        $tahun = new DateTime();
                        $tahun = $tahun->format('Y');
                    ?>
                    <a href="/agenda" class="btn btn-warning">Kembali</a>
                    <?php if($agenda->status == 'Pengajuan' and Auth::user()->level == 'admin'): ?>
                        <button type="button" class="btn btn-primary" data-toggle="modal"
                            data-target="#modal-default">Verifikasi</button>
                    <?php endif; ?>
                    <?php if($now >= $agenda->tanggal and $agenda->status != 'Selesai'): ?>
                        <a href="/agenda/selesai/<?php echo e(Crypt::encrypt($agenda->id)); ?>" class="btn btn-success">Selesai</a>
                    <?php endif; ?>
                </div>


                <div class="box-header">
                    <table class="table table-hover">
                        <tr>
                            <th style="width: 10%">Nama Rapat</th>
                            <td style="width: 50%"><?php echo e($agenda->nama_agenda); ?></td>
                            <th style="width: 10%">PIC Rapat</th>
                            <td style="width: 30%">
                                <?php echo e($agenda->userpic->name); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>Tanggal</th>
                            <td><?php echo e(\Carbon\Carbon::parse($agenda->tanggal)->format('d M Y')); ?></td>
                            <th>Pengundang Acara</th>
                            <td><?php echo e($agenda->pengundang); ?></td>
                        </tr>
                        <tr>
                            <th>Waktu</th>
                            <td><?php echo e($agenda->waktu_mulai . ' - ' . $agenda->waktu_selesai); ?></td>
                            <th>Peserta / Presensi</th>
                            <td><?php echo e($agenda->user->count()); ?> / <?php echo e($presensi); ?></td>
                        </tr>
                        <tr>
                            <th>Tempat</th>
                            <td><?php echo e($agenda->ruangan->nama); ?></td>
                            <th>Notulen</th>
                            <td>
                                <?php if(!empty($agenda->notulen)): ?>
                                    
                                    <a href="/notulen/view/<?php echo e($agenda->notulen); ?> " target="_blank"
                                        class="label label-success">Lihat File</a>
                                <?php else: ?>
                                    <span class="label label-warning">belum ada Notulen</span>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <th>Keterangan</th>
                            <td><?php echo e($agenda->keterangan); ?></td>
                            <th>Daftar Hadir</th>
                            <td>
                                <?php if(!empty($agenda->daftar)): ?>
                                    <?php echo e($agenda->daftar); ?>

                                    <a href="/daftarhadir/view/<?php echo e($agenda->daftar); ?> " target="_blank"
                                        class="label label-success">Daftar Hadir Luring</a>
                                <?php else: ?>
                                    <span class="label label-warning">belum ada Daftar Hadir Luring</span>
                                <?php endif; ?>
                                <a href="/presensi/hadir/<?php echo e(Crypt::encrypt($agenda->id)); ?>" target="_blank"
                                    class="label label-primary">Daring</a>
                            </td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <?php if($agenda->status == 'Pengajuan'): ?>
                                    <span class="label label-warning">
                                    <?php elseif($agenda->status == 'Dijadwalkan'): ?>
                                        <span class="label label-success">
                                        <?php else: ?>
                                            <span class="label label-default">
                                <?php endif; ?>
                                <?php echo e($agenda->status); ?></span>
                            </td>
                            <th>Materi</th>
                            <td>
                                <?php if(!empty($agenda->materi)): ?>
                                    <?php echo e($agenda->materi); ?>

                                    <a href="/materi/view/<?php echo e($agenda->materi); ?> " target="_blank"
                                        class="label label-success">Lihat Materi</a>
                                <?php else: ?>
                                    <span class="label label-warning">belum ada materi</span>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <th>Varifikator</th>
                            <td><?php echo e($agenda->verifikator); ?></td>
                            <th>Dokumentasi</th>
                            <td>
                                <?php $__empty_1 = true; $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <a href="/dokumentasi/view/<?php echo e($item->gambar); ?> " target="_blank"
                                        class="label label-success"><?php echo e($item->gambar); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <span class="label label-warning">belum ada dokumentasi</span>
                                <?php endif; ?>

                            </td>
                        </tr>
                        <tr>
                            <th>Catatan</th>
                            <td><?php echo e($agenda->catatan); ?></td>
                            <th>Undangan</th>
                            <td>
                                <a href="/undangan/view/<?php echo e(Crypt::encrypt($agenda->id)); ?> " target="_blank"
                                    class="label label-primary">Undangan</a>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <?php if(
                ($agenda->status != 'Pengajuan' or $agenda->status != 'Ditolak') and
                    (Auth::user()->level == 'admin' or Auth::user()->id == $agenda->pic)): ?>
                <div class="box box-info collapsed-box">
                    <div class="box-header">
                        <h3 class="box-title">PATRIK Notulen
                            <small>dari CK Editor</small>
                        </h3>
                        <!-- tools box -->
                        <div class="pull-right box-tools">
                            <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip"
                                title="Minimalkan">
                                <i class="fa fa-plus"></i></button>

                        </div>
                        <!-- /. tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body pad display:none">
                        <form method="POST" action="/notulen/save/<?php echo e($agenda->id); ?>">
                            <?php echo csrf_field(); ?>
                            <textarea id="editor1" name="notulen_ol" rows="10" cols="80">
                                                                                                                                                                                                                                                                                                                                                                                                                                                <?php echo e($agenda->notulen_ol); ?>

                                                                                                                                                                                                                                                                                                                                                                                                                                            </textarea>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary">Simpan</button>

                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
            <!-- /.box -->


            <?php if(
                ($agenda->status != 'Pengajuan' or $agenda->status != 'Ditolak') and
                    (Auth::user()->level == 'admin' or Auth::user()->id == $agenda->pic)): ?>
                <div class="box box-success">
                    <div class="box-body">
                        <div class="box-header table-hover">
                            <?php if($now <= $agenda->tanggal): ?>
                                <form role="form" action="/undangan/tambahpeserta/<?php echo e($id); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group col-md-12">
                                        <label>Undang Peserta Rapat</label>
                                    </div>

                                    <div class="form-group col-md-8">
                                        <input type="hidden" name="id" value="<?php echo e($id); ?>">
                                        <select class="form-control select2 " style="width: 100%;" name="peserta">
                                            <option selected value="" active>Pilih</option>
                                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($p->id); ?>">
                                                    <?php echo e($p->name . ' Unit ' . $p->unit->nama_unit); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary btn-sm"><i
                                                class="fa fa-plus-circle"></i> Tambah</button>
                                    </div>
                                    <div class="col-md-12">
                                        <?php if($errors->any()): ?>
                                            <div class="text-danger">
                                                <?php echo e($errors->first()); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            <?php endif; ?>
                            <?php if($now >= $agenda->tanggal and empty($agenda->notulen)): ?>
                                <form class="form-inline" action="/notulen/upload/<?php echo e($id); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group col-md-8">
                                        <strong>File Notulen dalam bentuk PDF (Maksimal 2Mb)</strong>
                                        <input type="file" name="filepdf">

                                    </div>

                                    <div class="form-group col-md-2">
                                        <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-upload">
                                                Upload</i></button>
                                    </div>
                                </form>
                            <?php endif; ?>
                            <?php if($errors->has('filepdf')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('filepdf')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($now >= $agenda->tanggal and empty($agenda->daftar)): ?>
                                <form action="/daftarhadir/upload/<?php echo e($id); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group col-md-8">
                                        <strong>File Daftar Hadir dalam bentuk PDF/JPEG (Maksimal 2Mb)</strong>
                                        <input type="file" name="filedaftar">

                                    </div>

                                    <div class="form-group col-md-2">
                                        <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-upload">
                                                Upload</i></button>
                                    </div>
                                </form>
                            <?php endif; ?>
                            <?php if($errors->has('filedaftar')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('filedaftar')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($now >= $agenda->tanggal and empty($agenda->materi)): ?>
                                <form action="/materi/upload/<?php echo e($id); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group col-md-8">
                                        <strong>File Materi dalam bentuk PDF/PPT/PPTX (Maksimal 2Mb)</strong>
                                        <input type="file" name="filemateri">

                                    </div>

                                    <div class="form-group col-md-2">
                                        <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-upload">
                                                Upload</i></button>
                                    </div>
                                </form>
                            <?php endif; ?>
                            <?php if($errors->has('filemateri')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('filemateri')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($now >= $agenda->tanggal): ?>
                                <form action="/dokumentasi/upload/<?php echo e($id); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group col-md-8">
                                        <strong>File dokumentasi dalam bentuk JPG/JPEG (Maksimal 1Mb)</strong>
                                        <input type="file" name="filedokumentasi">

                                    </div>

                                    <div class="form-group col-md-2">
                                        <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-upload">
                                                Upload</i></button>
                                    </div>
                                </form>
                            <?php endif; ?>
                            <?php if($errors->has('filedokumentasi')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('filedokumentasi')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="box box-primary">
                <div class="box-header">
                    <!-- /.box-header -->

                    <h4> <label>Daftar Peserta </label></h4>
                    <?php if($now <= $agenda->tanggal and $agenda->status != 'Selesai'): ?>
                        <a href="/presensi/email/<?php echo e(Crypt::encrypt($agenda->id)); ?>" class="btn btn-success"><i
                                class="fa fa-envelope"></i> Kirim Email</a>
                    <?php endif; ?>
                </div>

                <div class="box-body">
                    <table class="table table-hover" id="example1">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Unit</th>
                                <th>Status Presensi</th>
                                <th>Waktu Presensi</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $agenda->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$index); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->unit->nama_unit); ?></td>
                                    <td>
                                        <?php if($user->pivot->presensi == 'sudah'): ?>
                                            <span class="label label-success">
                                            <?php else: ?>
                                                <span class="label label-danger">
                                        <?php endif; ?>
                                        <?php echo e($user->pivot->presensi); ?></span>
                                    </td>
                                    <td>
                                        <?php if(!empty($user->pivot->presensi_at)): ?>
                                            <?php echo e(\Carbon\Carbon::parse($user->pivot->presensi_at)->format('d-m-Y H:i:s')); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(
                                            ($now < $agenda->tanggal or $user->pivot->presensi != 'sudah') and
                                                (Auth::user()->level == 'admin' or Auth::user()->id == $agenda->pic)): ?>
                                            <div class="btn-group">
                                                <a href="/undangan/<?php echo e($id); ?>/hapus/<?php echo e(Crypt::encrypt($user->id)); ?>"
                                                    class="btn btn-danger btn-sm" data-toggle="tooltip"
                                                    data-placement="bottom" title="Hapus"><i
                                                        class="fa fa-trash"></i></a>
                                            </div>
                                            <div class="btn-group">
                                                <a href="/presensi/<?php echo e($id); ?>/email/<?php echo e(Crypt::encrypt($user->id)); ?>"
                                                    class="btn btn-success btn-sm" data-toggle="tooltip"
                                                    data-placement="bottom" title="Kirim Email Presensi"><i
                                                        class="fa fa-envelope"></i></a>
                                            </div>
                                        <?php else: ?>
                                            <div class="btn-group">
                                                <a href="/undangan/<?php echo e($id); ?>/hapus/<?php echo e(Crypt::encrypt($user->id)); ?>"
                                                    class="btn btn-danger btn-sm disabled" data-toggle="tooltip"
                                                    data-placement="bottom" title="Hapus"><i
                                                        class="fa fa-trash"></i></a>
                                            </div>
                                            <div class="btn-group">
                                                <a href="/presensi/<?php echo e($id); ?>/email/<?php echo e(Crypt::encrypt($user->id)); ?>"
                                                    class="btn btn-success btn-sm disabled" data-toggle="tooltip"
                                                    data-placement="bottom" title="Kirim Email Presensi"><i
                                                        class="fa fa-envelope"></i></a>
                                            </div>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
            <!--modal -->
            <div class="modal fade" id="modal-default">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Verifikasi Agenda</h4>
                        </div>
                        <div class="modal-body">
                            <form method="post" action="/agenda/verifikasi">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label>Diverifikasi Oleh</label>
                                    <input type='hidden' class="form-control" name='id'
                                        value='<?php echo e($agenda->id); ?>' />
                                    <input type='text' class="form-control" name='verifikator'
                                        value='<?php echo e(Auth::user()->name); ?>' disabled />
                                </div>
                                <div class="form-group">
                                    <label>Pengajuan</label>
                                    <select class="form-control" style="width: 100%;" name="status">
                                        <option selected value="" active>Pilih Status</option>

                                        <option value="Dijadwalkan">Dijadwalkan</option>
                                        <option value="Ditolak">Ditolak</option>
                                    </select>
                                </div>
                                <?php if(!empty($eselon->pegawai->eselon)): ?>
                                    <div class="form-group">
                                        <label>No Undangan (Optional)</label>
                                        <div class="input-group">
                                            <span class="input-group-addon">UM.01.01/D.XXXI/
                                            </span>
                                            <input type='text' class="form-control" name='no_undangan' />
                                            <span class="input-group-addon">/<?php echo e($tahun); ?></span>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="form-group">
                                    <label>Catatan</label>
                                    <textarea class="form-control" rows="3" name='catatan' placeholder="Catatan"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default pull-left"
                                        data-dismiss="modal">Kembali</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <!-- CK Editor -->
    <script src="<?php echo e(asset('adminlte/bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="<?php echo e(asset('adminlte/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
    <script>
        $(function() {
            // Replace the <textarea id="editor1"> with a CKEditor
            // instance, using default configuration.
            CKEDITOR.replace('editor1')
            //bootstrap WYSIHTML5 - text editor
            $('.textarea').wysihtml5()
        })
    </script>
    <script>
        $(function() {
            $('#example1').DataTable()
            $('#example2').DataTable({
                'paging': true,
                'lengthChange': true,
                'searching': true,
                'ordering': true,
                'info': true,
                'autoWidth': false
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>