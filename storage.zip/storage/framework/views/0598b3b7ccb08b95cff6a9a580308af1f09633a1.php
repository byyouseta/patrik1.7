<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Daftar Pegawai'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<div class="row">
    <!-- left column -->
    <div class="col-md-8">
        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title">Edit Pegawai</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form role="form" action="/pegawai/update/<?php echo e($pegawai->id); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                
                <!-- text input -->
                    <div class="form-group">
                        <label>NIP</label>
                        <input type="text" class="form-control" placeholder="Masukkan NIP" name="username" value="<?php echo e($pegawai->username); ?>" disabled>
                        <?php if($errors->has('username')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('username')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" class="form-control" placeholder="Masukkan Nama" name="name" value="<?php echo e($pegawai->name); ?>">
                        <?php if($errors->has('name')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('name')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Alamat</label>
                        <textarea class="form-control" rows="3" placeholder="Masukkan Alamat" name="alamat"><?php echo e($pegawai->pegawai->alamat); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>No Handphone</label>
                        <input type="text" class="form-control" placeholder="Masukkan No Handphone" name="no_hp" value="<?php echo e($pegawai->pegawai->no_hp); ?>">
                        <?php if($errors->has('no_hp')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('no_hp')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" class="form-control" placeholder="Masukkan Email" name="email" value="<?php echo e($pegawai->email); ?>">
                        <?php if($errors->has('email')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Unit</label>
                        <select class="form-control" name="unit">
                            <option value="">Pilih</option>
                            <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($u->id); ?>" <?php if($u->id==$pegawai->unit_id): ?> selected <?php endif; ?>><?php echo e($u->nama_unit); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('unit')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('unit')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Hak Akses</label>
                        <select class="form-control" name="level">
                            <option value="">Pilih</option>
                            <option value="user" <?php if($pegawai->level=="user"): ?> selected <?php endif; ?>>User</option>
                            <option value="admin" <?php if($pegawai->level=="admin"): ?> selected <?php endif; ?>>Admin</option>
                        </select>
                        <?php if($errors->has('level')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('level')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a href="/pegawai" class="btn btn-warning">Kembali</a>
                    </div>
                </form>
            </div>
    <!-- /.box-body -->
        </div>
        <?php if(!empty($pesan)): ?>
        <div class="alert alert-success alert-block">
		        <button type="button" class="close" data-dismiss="alert">×</button>	
                <strong><?php echo e($pesan); ?></strong>
	    </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>