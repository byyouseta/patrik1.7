<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Agenda'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
        
        <div class="box-header">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?> <br/>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <a href="/agenda" class="btn btn-warning">Kembali</a>
            <?php if(($agenda->status == 'Pengajuan') AND (Auth::user()->level=='admin')): ?>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-default">Verifikasi</button>
            <?php endif; ?>
        </div>
        
        
        <div class="box-header">
            <table class="table table-hover" >
                <tr>
                    <th style="width: 10%">Nama Rapat</th><td style="width: 50%"><?php echo e($agenda->nama_agenda); ?></td>
                    <th style="width: 10%">PIC Rapat</th><td style="width: 30%"><?php echo e($agenda->pic); ?></td>
                </tr>
                <tr>
                    <th>Tanggal</th><td><?php echo e($agenda->tanggal); ?></td>
                    <th>Jumlah Peserta</th><td><?php echo e($agenda->user->count()); ?></td>
                </tr>
                <tr>
                    <th>Waktu</th><td><?php echo e($agenda->waktu_mulai .' - '. $agenda->waktu_selesai); ?></td>
                    <th>Peserta Presensi</th><td><?php echo e($presensi); ?></td>
                </tr>
                <tr>
                    <th>Tempat</th><td><?php echo e($agenda->ruangan->nama); ?></td>
                    <th>Notulen</th><td>
                    <?php if(!empty($agenda->notulen)): ?>
                        
                        <a href="/notulen/view/<?php echo e($agenda->notulen); ?> " target="_blank" class="label label-success">Lihat File</a>
                    <?php else: ?>
                        <span class="label label-warning">belum ada Notulen</span>
                    <?php endif; ?>
                    </td>
                </tr>
                
                <tr><th>Keterangan</th><td><?php echo e($agenda->keterangan); ?></td>
                    <th>Daftar Hadir</th><td>
                    <?php if(!empty($agenda->daftar)): ?>
                    <?php echo e($agenda->daftar); ?> 
                        <a href="/daftarhadir/view/<?php echo e($agenda->daftar); ?> " target="_blank" class="label label-success">Daftar Hadir Luring</a>
                    <?php else: ?>
                        <span class="label label-warning">belum ada Daftar Hadir Luring</span>
                    <?php endif; ?>
                        <a href="/presensi/hadir/<?php echo e(Crypt::encrypt($agenda->id)); ?> " target="_blank" class="label label-primary">Daring</a>
                    </td></tr>
                <tr><th>Status</th><td>
                    <?php if($agenda->status == 'Pengajuan' ): ?>
                        <span class="label label-warning">
                    <?php elseif($agenda->status == 'Dijadwalkan'): ?>
                        <span class="label label-success">
                    <?php else: ?>
                        <span class="label label-primary">
                    <?php endif; ?>
                    <?php echo e($agenda->status); ?></span>
                    </td><th>Materi</th><td>
                    <?php if(!empty($agenda->materi)): ?>
                        <?php echo e($agenda->materi); ?>

                        <a href="/materi/view/<?php echo e($agenda->materi); ?> " target="_blank" class="label label-success">Lihat Materi</a>                          
                    <?php else: ?>
                    <span class="label label-warning">belum ada materi</span>
                    <?php endif; ?>
                    </td></tr>
                
                    <tr>
                        <th>Varifikator</th><td><?php echo e($agenda->verifikator); ?></td>
                        <th>Dokumentasi</th><td>
                            <?php $__empty_1 = true; $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="/dokumentasi/view/<?php echo e($item->gambar); ?> " target="_blank" class="label label-success"><?php echo e($item->gambar); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <span class="label label-warning">belum ada dokumentasi</span>
                            <?php endif; ?>
                            
                        </td>
                    </tr>
                    <tr>
                        <th>Catatan</th><td><?php echo e($agenda->catatan); ?></td>
                        <th>Undangan</th><td>
                            <a href="/undangan/view/<?php echo e(Crypt::encrypt($agenda->id)); ?> " target="_blank" class="label label-primary">Undangan</a>
                        </td>
                    </tr>
                
            </table>
            
        </div>
    </div> 
    <?php if(($agenda->status <> 'Pengajuan') OR ($agenda->status <>'Ditolak')): ?>
    <div class="box box-info collapsed-box">
        <div class="box-header">
            <h3 class="box-title">PATRIK Notulen
            <small>dari CK Editor</small>
            </h3>
            <!-- tools box -->
            <div class="pull-right box-tools">
            <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip"
                    title="Minimalkan">
                <i class="fa fa-plus"></i></button>
            
            </div>
            <!-- /. tools -->
        </div>
        <!-- /.box-header -->
        <div class="box-body pad display:none">
            <form method="POST" action="/notulen/save/<?php echo e($agenda->id); ?>">
                <?php echo csrf_field(); ?>
                <textarea id="editor1" name="notulen_ol" rows="10" cols="80">
                    <?php echo e($agenda->notulen_ol); ?>

                </textarea>
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <a href="/agenda" class="btn btn-warning">Kembali</a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
      <!-- /.box -->

    <?php 
        $no=1; 
        $now = new DateTime();
        $now = $now->format('Y-m-d'); 
    ?>
    <?php if(($agenda->status <> 'Pengajuan') OR ($agenda->status <>'Ditolak')): ?>

    <div class="box box-success">
        <div class="box-body">
            <?php if(($now <= $agenda->tanggal) AND ((Auth::user()->level=='admin') OR (Auth::user()->name==$agenda->pic))): ?>
                <form role="form" action="/undangan/tambahpeserta/<?php echo e($id); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="box-header table-hover">
                        <div class="form-group col-md-12">
                            <label>Daftar Peserta Rapat</label>
                        </div>
                    <div class="form-group col-md-8">
                        <input type="hidden" name="id" value="<?php echo e($id); ?>">
                        <select class="form-control select2 " style="width: 100%;" name="peserta">
                        <option selected value="" active>Pilih</option>
                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p->id); ?>"><?php echo e($p->name ." Unit ". $p->unit->nama_unit); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                    </div>
                    
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-plus-circle"></i> Tambah</button>
                    </div>
                    <div class="col-md-12">
                        <?php if($errors->any()): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </form>
            <?php endif; ?>
            <?php if(($now >= $agenda->tanggal) AND ((empty($agenda->notulen)) AND ((Auth::user()->name==$agenda->pic) OR (Auth::user()->level=='admin')))): ?>
                <form class="form-inline" action="/notulen/upload/<?php echo e($id); ?>" method="POST" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>


					<div class="form-group col-md-8">
						<strong>File Notulen dalam bentuk PDF (Maksimal 2Mb)</strong>
						<input type="file" name="filepdf">
                        
					</div>
 
					<div class="form-group col-md-2">
					    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-upload"> Upload</i></button>
                    </div>
				</form>
            <?php endif; ?>
                <?php if($errors->has('filepdf')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('filepdf')); ?>

                    </div>
                <?php endif; ?>
            <?php if(($now >= $agenda->tanggal) AND ((empty($agenda->daftar)) AND ((Auth::user()->name==$agenda->pic) OR (Auth::user()->level=='admin')))): ?>
                <form action="/daftarhadir/upload/<?php echo e($id); ?>" method="POST" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

 
					<div class="form-group col-md-8">
						<strong>File Daftar Hadir dalam bentuk PDF/JPEG (Maksimal 2Mb)</strong>
						<input type="file" name="filedaftar">
                        
					</div>
 
					<div class="form-group col-md-2">
					    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-upload"> Upload</i></button>
                    </div>
				</form>
            <?php endif; ?>
                <?php if($errors->has('filedaftar')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('filedaftar')); ?>

                    </div>
                <?php endif; ?>
            <?php if(($now >= $agenda->tanggal) AND ((empty($agenda->materi)) AND ((Auth::user()->name==$agenda->pic) OR (Auth::user()->level=='admin')))): ?>
                <form action="/materi/upload/<?php echo e($id); ?>" method="POST" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

 
					<div class="form-group col-md-8">
						<strong>File Materi dalam bentuk PDF/PPT/PPTX (Maksimal 2Mb)</strong>
						<input type="file" name="filemateri">
                        
					</div>
 
					<div class="form-group col-md-2">
					    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-upload"> Upload</i></button>
                    </div>
				</form>
            <?php endif; ?>
                <?php if($errors->has('filemateri')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('filemateri')); ?>

                    </div>
                <?php endif; ?>
            <?php if(($now >= $agenda->tanggal) AND ((Auth::user()->name==$agenda->pic) OR (Auth::user()->level=='admin'))): ?>
                <form action="/dokumentasi/upload/<?php echo e($id); ?>" method="POST" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

 
					<div class="form-group col-md-8">
						<strong>File dokumentasi dalam bentuk JPG/JPEG (Maksimal 1Mb)</strong>
						<input type="file" name="filedokumentasi">
                        
					</div>
 
					<div class="form-group col-md-2">
					    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-upload"> Upload</i></button>
                    </div>
				</form>
            <?php endif; ?>
                <?php if($errors->has('filedokumentasi')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('filedokumentasi')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="box box-primary">
        <div class="box-header">
        <!-- /.box-header -->
            <h4> <label>Daftar Peserta </label></h4>
            <div class="box-tools">
                <form action="/undangan/cari/<?php echo e(Crypt::encrypt($agenda->id)); ?>" method="get">
                    <div class="input-group input-group-sm" style="width: 150px;">
                        <input type="text" name="cari" class="form-control pull-right" placeholder="Search">
                        
                        <div class="input-group-btn">
                            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
     
    <div class="box-body">
        <div class="box-body table-responsive no-padding">
            <?php $no=1; ?>
            <table class="table table-hover">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Unit</th>
                <th>Status Presensi</th>
                <th>Waktu Presensi</th>
                <th>Action</th>
            </tr>
            <?php if(!empty($cari)): ?>
                <?php $__currentLoopData = $cari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->nama_unit); ?></td>
                    <td><?php if($user->presensi=='sudah'): ?>
                        <span class="label label-success">
                    <?php else: ?>
                        <span class="label label-danger">
                    <?php endif; ?>
                        <?php echo e($user->presensi); ?></span></td>
                    <td><?php echo e($user->presensi_at); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $agenda->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->unit->nama_unit); ?></td>
                    <td>
                    <?php if($user->pivot->presensi=='sudah'): ?>
                        <span class="label label-success">
                    <?php else: ?>
                        <span class="label label-danger">
                    <?php endif; ?>
                        <?php echo e($user->pivot->presensi); ?></span></td>
                    <td><?php echo e($user->pivot->presensi_at); ?></td>
                    <td>
                    <?php if(($now < $agenda->tanggal) OR ($user->pivot->presensi!='sudah')): ?>
                        <div class="btn-group">
                            <a href="/undangan/<?php echo e($id); ?>/hapus/<?php echo e(Crypt::encrypt($user->id)); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
                        </div>
                    <?php else: ?>
                        <div class="btn-group">
                            <a href="/undangan/<?php echo e($id); ?>/hapus/<?php echo e(Crypt::encrypt($user->id)); ?>" class="btn btn-danger btn-sm" disabled><i class="fa fa-trash-o"></i></a>
                        </div>
                    <?php endif; ?>
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </table>
        </div>
        
    <!-- /.box-body -->
    </div>
        
        <!-- /.box -->
    </div>
    
    <!--modal -->
    <div class="modal fade" id="modal-default">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Verifikasi Agenda</h4>
            </div>
            <div class="modal-body">
            <form method="post" action="/agenda/verifikasi">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label>Diverifikasi Oleh</label>
                        <input type='hidden' class="form-control" name='id' value='<?php echo e($agenda->id); ?>' />
                        <input type='text' class="form-control" name='verifikator' value='<?php echo e(Auth::user()->name); ?>' disabled/>
                    </div>
                    <div class="form-group">
                        <label>Pengajuan</label>
                        <select class="form-control" style="width: 100%;" name="status">
                        <option selected value="" active>Pilih Status</option>
                            
                                <option value="Dijadwalkan">Dijadwalkan</option>
                                <option value="Ditolak">Ditolak</option>
                        </select>
                        
                    </div>
                    <div class="form-group">
                        <label>Catatan</label>
                        <textarea class="form-control" rows="3" name='catatan' placeholder="Catatan"></textarea>
                    </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Kembali</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
        <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>